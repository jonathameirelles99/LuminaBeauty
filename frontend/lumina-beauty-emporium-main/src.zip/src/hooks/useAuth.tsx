import { useEffect, useState } from "react";
import { getCurrentUser, type LocalUser } from "@/lib/local-store";

export function useAuth() {
  const [user, setUser] = useState<LocalUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const refresh = () => {
      setUser(getCurrentUser());
      setLoading(false);
    };
    refresh();
    window.addEventListener("lumina-auth-change", refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener("lumina-auth-change", refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  return { session: user ? { user } : null, user, loading };
}
