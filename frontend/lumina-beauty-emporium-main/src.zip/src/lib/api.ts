const BASE = "http://localhost:5000/api";

function getToken() {
  return localStorage.getItem("lumina_token");
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error((err as any).message ?? "Erro na requisição");
  }
  return res.json() as T;
}

export const api = {
  // Auth
  register: (data: { email: string; password: string; full_name: string; phone: string }) =>
    request<{ token: string; user: any }>("/auth/register", { method: "POST", body: JSON.stringify(data) }),

  login: (email: string, password: string) =>
    request<{ token: string; user: any }>("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }),

  me: () => request<any>("/auth/me"),

  updateProfile: (data: { fullName: string; phone: string }) =>
    request<any>("/auth/me", { method: "PUT", body: JSON.stringify(data) }),

  // Produtos
  getProducts: (params?: { category?: string; subcategory?: string; search?: string }) => {
    const qs = new URLSearchParams(params as any).toString();
    return request<any[]>(`/products${qs ? `?${qs}` : ""}`);
  },

  saveProduct: (data: any) =>
    data.id
      ? request<any>(`/products/${data.id}`, { method: "PUT", body: JSON.stringify(data) })
      : request<any>("/products", { method: "POST", body: JSON.stringify(data) }),

  deleteProduct: (id: string) =>
    request<void>(`/products/${id}`, { method: "DELETE" }),

  // Pedidos
  getOrders: () => request<any[]>("/orders"),
  createOrder: (data: any) => request<any>("/orders", { method: "POST", body: JSON.stringify(data) }),
  updateOrderStatus: (id: string, status: string) =>
    request<any>(`/orders/${id}/status`, { method: "PATCH", body: JSON.stringify({ status }) }),

  // Cupons
  getCoupons: () => request<any[]>("/coupons"),
  applyCoupon: (code: string) => request<any>(`/coupons/apply?code=${code}`),
  saveCoupon: (data: any) =>
    data.id
      ? request<any>(`/coupons/${data.id}`, { method: "PUT", body: JSON.stringify(data) })
      : request<any>("/coupons", { method: "POST", body: JSON.stringify(data) }),
  deleteCoupon: (id: string) =>
    request<void>(`/coupons/${id}`, { method: "DELETE" }),
};