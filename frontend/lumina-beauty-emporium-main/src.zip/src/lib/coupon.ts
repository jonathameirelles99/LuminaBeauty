import { getCoupons, type LocalCoupon } from "@/lib/local-store";

export type Coupon = Omit<LocalCoupon, "created_at">;

export async function findCoupon(code: string): Promise<Coupon | null> {
  const c = code.trim().toUpperCase();
  if (!c) return null;
  const data = getCoupons().find((coupon) => coupon.code === c && coupon.active);
  if (!data) return null;
  const now = new Date();
  if (data.ends_at && new Date(data.ends_at) < now) return null;
  if (new Date(data.starts_at) > now) return null;
  return data;
}

export function calcDiscount(subtotal: number, coupon: Coupon | null): number {
  if (!coupon) return 0;
  if (coupon.discount_type === "percent") {
    return Math.min(subtotal, +(subtotal * (coupon.discount_value / 100)).toFixed(2));
  }
  return Math.min(subtotal, coupon.discount_value);
}
