import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Lock } from "lucide-react";
import { Header } from "@/components/Header";
import { signInLocal, signOutLocal } from "@/lib/local-store";

export const Route = createFileRoute("/login-admin")({
  component: LoginAdminPage,
});

function LoginAdminPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = signInLocal(email, password);
      setLoading(false);
      if (user.role !== "admin") {
        signOutLocal();
        toast.error("Acesso negado: usuário não é administrador.");
        return;
      }
      toast.success("Bem-vinda!");
      navigate({ to: "/admin" });
    } catch (error) {
      setLoading(false);
      toast.error(error instanceof Error ? error.message : "Falha no login");
    }
  };

  return (
    <div className="min-h-screen bg-hero">
      <Header />
      <main className="mx-auto flex max-w-md flex-col px-4 py-16 lg:px-8">
        <div className="rounded-3xl border border-border/60 bg-card p-8 shadow-elegant">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-gold/15">
            <Lock className="h-6 w-6 text-gold-foreground" />
          </div>
          <h1 className="mt-5 text-center font-display text-3xl">Acesso restrito</h1>
          <p className="mt-1 text-center text-sm text-muted-foreground">Painel administrativo Lumina</p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <label className="block">
              <span className="mb-1.5 block text-xs font-medium text-foreground/70">E-mail</span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-primary/60"
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-xs font-medium text-foreground/70">Senha</span>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-primary/60"
              />
            </label>
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-soft transition-all hover:scale-[1.02] disabled:opacity-50"
            >
              {loading ? "Entrando…" : "Entrar"}
            </button>
          </form>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            Acesso disponível apenas para administradores cadastrados.
          </p>
        </div>
      </main>
    </div>
  );
}
